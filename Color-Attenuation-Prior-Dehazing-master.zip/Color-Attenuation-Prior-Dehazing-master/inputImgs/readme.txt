Put the input hazy images in this directory.
