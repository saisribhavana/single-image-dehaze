This directory is used for saving the result images.
